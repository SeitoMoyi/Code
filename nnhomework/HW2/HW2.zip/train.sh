#!/usr/bin/env bash

python3 train.py $1 $2