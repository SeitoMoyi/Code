#!/usr/bin/env bash

python3 test.py $1 $2